

package mn.univision.secretroom.data.entities

data class MovieCategoryDetails(
    val id: String,
    val name: String,
    val movies: MovieList,
)
