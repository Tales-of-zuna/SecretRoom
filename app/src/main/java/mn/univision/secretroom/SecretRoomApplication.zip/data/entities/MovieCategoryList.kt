

package mn.univision.secretroom.data.entities

typealias MovieCategoryList = List<MovieCategory>
