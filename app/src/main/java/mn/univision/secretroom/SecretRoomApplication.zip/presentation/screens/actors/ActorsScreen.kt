package mn.univision.secretroom.presentation.screens.actors

import androidx.compose.runtime.Composable
import androidx.tv.material3.Text

@Composable
fun ActorsScreen(

) {
    Text(text = "Hello Ators")
}