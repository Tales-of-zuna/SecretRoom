

package mn.univision.secretroom.data.entities

typealias MovieList = List<Movie>
