package mn.univision.secretroom.presentation.screens.shop

import androidx.compose.runtime.Composable
import androidx.tv.material3.Text

@Composable
fun ShopScreen() {
    Text(text = "Hello Shop")
}